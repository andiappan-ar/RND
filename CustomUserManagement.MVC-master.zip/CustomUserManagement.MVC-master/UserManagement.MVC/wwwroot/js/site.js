﻿var OMNIA_ID_Managemenet = (function () {
    // private member
    var counter = 0;

    return {

        init: function () {
            OMNIA_ID_Managemenet.Modules.JsonEditor.AddConfigurationManager();
            OMNIA_ID_Managemenet.Modules.JsonEditor.EditConfigurationManager();
        }
        ,
        Modules: {
            JsonEditor: {
                AddConfigurationManager: function () {
                    if ($('#add_configurationJSON-DIV').length > 0) {
                        var myjson = {
                            key1: {
                                Key_string: "https://url.com/r",
                                Key_int: 1234,
                                Key_arrString: ["a", "b", "c"],
                                Key_arrInteger: [1, 2, 3],
                                Key_NestedObject: {
                                    Key_inner: "abc"
                                }
                            },
                            key2: ""
                        };

                        var opt = {
                            change: function (data) {

                                var jsonParsed = "";

                                if (data) {
                                    try {                                        
                                        $("#configurationJSON").val(JSON.stringify(data));
                                    }
                                    catch (e) { alert('Error in parsing json. ' + e); }
                                } else {
                                    jsonParsed = JSON.stringify(myjson);
                                }

                                
                            },
                            propertyclick: function (path) { /* called when a property is clicked with the JS path to that property */ }
                        };
                        //opt.propertyElement = '<textarea>';  // element of the property field, <input> is default
                        //opt.valueElement = '<textarea>';   // element of the value field, <input> is default
                        $('#add_configurationJSON-DIV').jsonEditor(myjson, opt);
                        $("#configurationJSON").val(JSON.stringify(myjson));
                    }
                }
                ,
                EditConfigurationManager: function () {
                    if ($('#edit_configurationJSON-DIV').length > 0) {
                        var myjson = null;
                        var jsonParsed = $("#configurationJSON").val();

                        if (jsonParsed) {
                            try {
                                myjson = JSON.parse(jsonParsed);
                                var opt = {
                                    change: function (data) {
                                        $("#configurationJSON").val(JSON.stringify(data));
                                    },
                                    propertyclick: function (path) { /* called when a property is clicked with the JS path to that property */ }
                                };
                                //opt.propertyElement = '<textarea>';  // element of the property field, <input> is default
                                //opt.valueElement = '<textarea>';   // element of the value field, <input> is default
                                $('#edit_configurationJSON-DIV').jsonEditor(myjson, opt);
                                $("#configurationJSON").val(JSON.stringify(myjson));
                            }
                            catch (e) { alert('Error in parsing json. ' + e); }
                        } else {
                            jsonParsed = JSON.parse({});
                        }                      

                        
                    }
                }
            }
        }
        ,
        EventListners: function () {

        }
    };

})();

$(function () {
    OMNIA_ID_Managemenet.init();
});