﻿using System.Collections.Generic;

namespace OMNIA.MS.ID.Management.Common
{
    public static class SiteConstants
    {
        public static int ArchievedVersionsCount = 3;

        public static string FormCode_Success = "FormCode_Success";
        public static string FormCode_Fail = "FormCode_Fail";

        public static string RequiredField = "{0} field required!";

        public static string UniqueField = "{0} field should be unique. Please provide different {0}.";
        public static string NoChanges = "No changes in {0}.";

        public static string NoRowsFound = "No rows found for {0}.";

        public static string TechnicalError = "Technical error occured.";


        public static string RowSuccessfullyInserted = "{0} successfully added!";
        public static string RowInsertFailed = "{0} insert failed.";

        public static string RowSuccessfullyEdited = "{0} successfully edited!";
        public static string RowEditFailed = "{0} edit failed.";

        public static string RowSuccessfullyDelete = "{0} successfully deleted!";
        public static string RowDeleteFailed = "{0} delete failed.";

        public static List<string> SystemRolesList = new List<string>() { "SuperAdmin", "ProjectAdmin" };

        public static class RolesConstant
        {
            public static string SuperAdmin = "SuperAdmin";
            public static string ProjectAdmin = "ProjectAdmin";
            public static string Basic = "Basic";
        }
    }
}
