﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using OMNIA.MS.ID.Management.Models.EntityModels;

namespace OMNIA.MS.ID.Management.Data;

public partial class OMNIADbContext : DbContext
{
    public OMNIADbContext()
    {
    }

    public OMNIADbContext(DbContextOptions<OMNIADbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<OmniaArchivedConfiguration> OmniaArchivedConfigurations { get; set; }

    public virtual DbSet<OmniaProject> OmniaProjects { get; set; }

    public virtual DbSet<OmniaConfiguration> OmniaConfigurations { get; set; }

    //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

    //    => optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=OMNIA.MMP;User Id=saaa;Password=saaa@123;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<OmniaProject>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Omnia.Pr__3214EC07C0D8FF4A");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
