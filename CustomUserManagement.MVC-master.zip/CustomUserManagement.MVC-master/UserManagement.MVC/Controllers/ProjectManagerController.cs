﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using OMNIA.MS.ID.Management.Common;
using OMNIA.MS.ID.Management.Data;
using OMNIA.MS.ID.Management.Models.EntityModels;
using OMNIA.MS.ID.Management.Models.ViewModels;

namespace OMNIA.MS.ID.Management.Controllers
{
    //[Authorize(Roles = "SuperAdmin")]
    public class ProjectManagerController : Controller
    {
        private readonly OMNIADbContext _contextFactory;
        private readonly RoleManager<IdentityRole> _roleManager;
        public ProjectManagerController([FromServices] OMNIADbContext contextFactory, RoleManager<IdentityRole> roleManager)
        {
            _contextFactory = contextFactory;
            _roleManager = roleManager;
        }


        public async Task<IActionResult> Index()
        {
            List<ProjectManagerModel> pmModel = new List<ProjectManagerModel>();
            try
            {

                List<OmniaProject> omniaProject = _contextFactory.OmniaProjects.ToList();
                foreach (OmniaProject prj in omniaProject)
                {
                    ProjectManagerModel pm = new ProjectManagerModel()
                    {
                        Id = prj.Id,
                        ProjectName = prj.ProjectName,
                        RoleId = prj.RoleId,
                        RoleName = _roleManager.Roles.Where(x => x.Id.Equals(prj.RoleId)).FirstOrDefault()?.Name
                    };

                    pmModel.Add(pm);
                }
            }
            catch (Exception ex)
            {

            }
            TempData.Put("Roles", _roleManager.Roles);

            return View(pmModel);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteProject(int projectId)
        {
            FormStatus formStatus = new FormStatus();

            try
            {
                OmniaProject _project = (projectId != 0) ? _contextFactory.OmniaProjects.
                    Where(x => x.Id == projectId).FirstOrDefault() : null;

                if (_project != null)
                {
                    formStatus = new FormStatus();

                    var result = _contextFactory.Remove(_project);
                    _contextFactory.SaveChanges();

                    formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                    formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyDelete, "Project");
                }
                else
                {
                    formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                    formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "Project Id");
                }
            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = ex.ToString();
            }


            TempData.Put("FormStatus", formStatus);           

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> AddProject(string projectName, string roleId)
        {
            FormStatus formStatus = new FormStatus();

            try
            {
                // Add Row
                // Required field check
                if (!string.IsNullOrEmpty(projectName) && !string.IsNullOrEmpty(roleId))
                {

                    OmniaProject _project = _contextFactory.OmniaProjects.
                        Where(x => x.ProjectName.Equals(projectName)).FirstOrDefault();

                    if (_project == null)
                    {
                        _project = new OmniaProject()
                        {
                            ProjectName = projectName,
                            RoleId = roleId
                        };

                        var result = _contextFactory.Add(_project);
                        _contextFactory.SaveChanges();
                        // Success
                        formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                        formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyInserted, "Project");
                    }
                    // Duplicate error
                    else
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                        formStatus.FormStatusMessage = String.Format(SiteConstants.UniqueField, "Project Name");
                    }

                }
                else
                {
                    formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                    formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "projectName and role");
                }

            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = String.Format(SiteConstants.RowInsertFailed, "Role Name");
            }


            TempData.Put("FormStatus", formStatus);
            TempData.Put("Roles", _roleManager.Roles);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> EditProject(int projectId, string projectName, string roleId, bool isView)
        {
            FormStatus formStatus = new FormStatus();
            OmniaProject _project = null;
            ViewBag.isView = isView;

            try
            {
                if (!isView)
                {
                    // Validation check
                    if (projectId != 0 && !string.IsNullOrEmpty(projectName) && !string.IsNullOrEmpty(roleId) )
                    {
                        var projectWithExistingNameCheck = _contextFactory.OmniaProjects.Where(x => x.ProjectName.Equals(projectName)).FirstOrDefault();
                        _project = (projectId != 0) ? _contextFactory.OmniaProjects.Where(x => x.Id == projectId).FirstOrDefault() : null;

                        // Project Id validation
                        if(_project!=null)
                        {
                            // Duplicate project name check
                            if (projectWithExistingNameCheck != null && projectWithExistingNameCheck.Id != _project.Id)
                            {
                                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                                formStatus.FormStatusMessage = String.Format(SiteConstants.UniqueField, "Project Name");
                            }
                            // No changes
                            else
                            if (String.Equals(projectName, _project.ProjectName) &&
                                String.Equals(roleId, _project.RoleId))
                            {
                                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                                formStatus.FormStatusMessage = String.Format(SiteConstants.NoChanges, "in the field Roles and Project name");
                            }
                            // Successfull edit
                            else
                            {
                                _project.ProjectName = projectName;
                                _project.RoleId = roleId;

                                var result = _contextFactory.Update(_project);
                                _contextFactory.SaveChanges();

                                // Success full edit
                                formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                                formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyEdited, "Project");
                            }
                        }
                        else
                        {
                            formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                            formStatus.FormStatusMessage = String.Format(SiteConstants.NoRowsFound, "Project Id");
                        }
                    }
                    else
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                        formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "projectName and role");
                    }
                }
                else
                {
                    _project = new OmniaProject()
                    {
                        Id = projectId,
                        ProjectName = projectName,                        
                        RoleId = roleId
                    };
                }
                

            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = String.Format(SiteConstants.RowInsertFailed, "Role Name");
            }

            TempData.Put("Roles", _roleManager.Roles);
            TempData.Put("FormStatus", formStatus);

            return View(_project);
        }
    }
}