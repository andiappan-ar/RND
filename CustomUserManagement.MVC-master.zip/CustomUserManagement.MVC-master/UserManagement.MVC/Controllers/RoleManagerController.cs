﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using OMNIA.MS.ID.Management.Common;
using OMNIA.MS.ID.Management.Models.ViewModels;

namespace OMNIA.MS.ID.Management.Controllers
{
    //[Authorize(Roles = "SuperAdmin")]
    public class RoleManagerController : Controller
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        public RoleManagerController(RoleManager<IdentityRole> roleManager)
        {
            _roleManager = roleManager;
        }

        
        public async Task<IActionResult> Index()
        {
            var roles = await _roleManager.Roles.ToListAsync();
            return View(roles);
        }

        [HttpPost]
        public async Task<IActionResult> AddRole(string roleName)
        {
            FormStatus formStatus = null;

            try
            {
                // Required field validation
                if (!string.IsNullOrEmpty(roleName))
                {
                    formStatus = new FormStatus();
                    var result = await _roleManager.CreateAsync(new IdentityRole(roleName.Trim()));

                    // DB Error
                    if (result.Errors.Any())
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                        formStatus.FormStatusMessage = String.Join(", ", result.Errors.Select(x => x.Description));
                    }
                    // Success
                    else
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                        formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyInserted, "Role");
                    }
                }
                // Missing Required field
                else
                {
                    formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                    formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "Role");
                }
            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = String.Format(SiteConstants.RowInsertFailed, "Role Name");
            }


            TempData.Put("FormStatus", formStatus);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> DeleteRole(string roleId)
        {
            FormStatus formStatus = new FormStatus();

            try
            {
                var role = !string.IsNullOrEmpty(roleId) ? await _roleManager.FindByIdAsync(roleId) : null;
                // Required field validation
                if (role != null)
                {
                    formStatus = new FormStatus();

                    // Check the role is assigned in any projects

                    var result = await _roleManager.DeleteAsync(role);
                    // DB Error
                    if (result.Errors.Any())
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                        formStatus.FormStatusMessage = String.Join(", ", result.Errors.Select(x => x.Description));
                    }
                    // Success
                    else
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                        formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyDelete, "Role");
                    }
                }
                // Missing Required field
                else
                {
                    formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                    formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "Role Id");
                }
            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = SiteConstants.TechnicalError+ ex.ToString();
            }


            TempData.Put("FormStatus", formStatus);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> EditRole(string roleId, string roleName,bool isView)
        {
            FormStatus formStatus = new FormStatus();

            IdentityRole resultRole = null;
            ViewBag.isView = isView;

            try
            {
                resultRole = !string.IsNullOrEmpty(roleId) ? await _roleManager.FindByIdAsync(roleId) : null;

                if(!isView)
                {
                    if (resultRole != null)
                    {
                        formStatus = new FormStatus();

                        var roleWithExistName = !string.IsNullOrEmpty(roleName) ? await _roleManager.FindByNameAsync(roleName) : null;

                        // Check role name is already exist
                        if (roleWithExistName == null)
                        {
                            resultRole.Name = roleName;
                            var result = await _roleManager.UpdateAsync(resultRole);
                            // DB Error
                            if (result.Errors.Any())
                            {
                                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                                formStatus.FormStatusMessage = String.Join(", ", result.Errors.Select(x => x.Description));
                            }
                            else
                            {
                                // Success full edit
                                formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                                formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyEdited, "Role");
                            }
                        }
                        // No changes
                        else if (String.Equals(roleName, resultRole.Name,StringComparison.OrdinalIgnoreCase))
                        {
                            formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                            formStatus.FormStatusMessage = String.Format(SiteConstants.NoChanges, "in the field Role Name");
                        }
                        // Duplicate error
                        else
                        {
                            formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                            formStatus.FormStatusMessage = String.Format(SiteConstants.UniqueField, "Role Name");
                        }


                    }
                    // Missing Required field
                    else
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                        formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "Role Id");
                    }
                }
                
            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = ex.ToString();
            }


            TempData.Put("FormStatus", formStatus);

            return View(resultRole);
        }

        

        
    }
}