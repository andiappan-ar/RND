﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OMNIA.MS.ID.Management.Common;
using OMNIA.MS.ID.Management.Data;
using OMNIA.MS.ID.Management.Models.EntityModels;
using OMNIA.MS.ID.Management.Models.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using System.Linq;
using Microsoft.IdentityModel.Tokens;
using Microsoft.EntityFrameworkCore.Internal;

namespace OMNIA.MS.ID.Management.Controllers
{
    //[Authorize(Roles = "SuperAdmin")]
    public class ConfigurationManagerController : Controller
    {
        private readonly OMNIADbContext _contextFactory;
        private readonly RoleManager<IdentityRole> _roleManager;
        public ConfigurationManagerController([FromServices] OMNIADbContext contextFactory, RoleManager<IdentityRole> roleManager)
        {
            _contextFactory = contextFactory;
            _roleManager = roleManager;
        }


        public async Task<IActionResult> Index()
        {
            FormStatus formStatus = new FormStatus();

            List<ConfigurationManagerModel> cgModel = new List<ConfigurationManagerModel>();
            try
            {
                // Get the 
                List<OmniaConfiguration> omniaConfigurations = _contextFactory.OmniaConfigurations.ToList();
                foreach (OmniaConfiguration config in omniaConfigurations)
                {
                    ConfigurationManagerModel pm = new ConfigurationManagerModel()
                    {
                        Id = config.Id,
                        ConfigurationName = config.ConfigurationName,
                        ConfigurationVersion = config.ConfigurationVersion,
                        ConfigurationJson = config.ConfigurationJson,
                        ProjectId= config.ProjectId,
                        ProjectName = _contextFactory.OmniaProjects.Where(x=>x.Id== config.ProjectId)?.FirstOrDefault()?.ProjectName
                    };

                    cgModel.Add(pm);
                }
            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = SiteConstants.TechnicalError;
            }

            TempData.Put("FormStatus", formStatus);
            return View(cgModel);
        }
        
        public async Task<IActionResult> GetConfigurationById(int configId)
        {
            OmniaConfiguration result = null;
            try
            {
                // Get the 
                result = _contextFactory.OmniaConfigurations.Where(x=>x.Id == configId).FirstOrDefault();
            }
            catch (Exception ex)
            {
               
            }

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> AddConfiguration(string configurationName,int projectId, string configurationJson, bool isView)
        {
            FormStatus formStatus = new FormStatus();
            OmniaConfiguration _config = null;
            ViewBag.isView = isView;

            try
            {
                if (!isView)
                {
                    // Add Row
                    // Required field check
                    if (projectId!=0 && !string.IsNullOrEmpty(configurationName) && !string.IsNullOrEmpty(configurationJson))
                    {

                        _config = _contextFactory.OmniaConfigurations?.
                            Where(x => x.ProjectId == projectId && 
                            x.ConfigurationName.Equals(configurationName))?.FirstOrDefault();

                        if (_config == null)
                        {
                            _config = new OmniaConfiguration()
                            {
                                ProjectId = projectId,
                                ConfigurationName = configurationName,
                                ConfigurationJson = configurationJson,
                                ConfigurationVersion = 1
                            };

                            var result = _contextFactory.Add(_config);
                            _contextFactory.SaveChanges();
                            // Success
                            formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                            formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyInserted, "Configuration");

                            
                        }
                        // Duplicate error
                        else
                        {
                            formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                            formStatus.FormStatusMessage = String.Format(SiteConstants.UniqueField, "Configuration Name && Project Id");
                        }

                    }
                    else
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                        formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "Configuration and Project Id");
                    }
                }
                

            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = String.Format(SiteConstants.RowInsertFailed, "Configuration");
            }


            TempData.Put("FormStatus", formStatus);
            TempData.Put("Projects", _contextFactory.OmniaProjects);

            return View(_config);

        }

        [HttpPost]
        public async Task<IActionResult> EditConfiguration(int configurationId, string configurationName, int projectId, string configurationJson, bool isView)
        {
            FormStatus formStatus = new FormStatus();
            OmniaConfiguration _config = null;
            ViewBag.isView = isView;

            try
            {
                _config = (projectId != 0) ?
                           _contextFactory.OmniaConfigurations.Where(x => x.Id == configurationId).FirstOrDefault()
                           : null;

                if (!isView)
                {
                    // Validation check
                    if (projectId != 0 && !string.IsNullOrEmpty(configurationName) && !string.IsNullOrEmpty(configurationJson))
                    {
                        

                        var _configWithExistingNameCheck = _contextFactory.OmniaConfigurations?.
                           Where(x=> x.ProjectId == projectId && x.ConfigurationName.Equals(configurationName))?.FirstOrDefault();
                       

                        // Configuration Id validation
                        if (_config != null)
                        {
                            // Duplicate configuration name check
                            if (_configWithExistingNameCheck != null && _configWithExistingNameCheck.Id != _config.Id)
                            {
                                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                                formStatus.FormStatusMessage = String.Format(SiteConstants.UniqueField, "Configuration Name & Project");
                            }
                            // No changes
                            else
                            if (String.Equals(configurationName, _config.ConfigurationName, StringComparison.OrdinalIgnoreCase) &&
                                projectId==_config.ProjectId 
                                && String.Equals(configurationJson, _config.ConfigurationJson, StringComparison.OrdinalIgnoreCase))
                            {
                                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                                formStatus.FormStatusMessage = String.Format(SiteConstants.NoChanges, "in the field Configuration Name , Json and Project Id");
                            }
                            // Successfull edit
                            else
                            {
                                // Archieve the configuration before saving
                                ArchieveConfiguration(_config);

                                _config.ConfigurationName = configurationName;
                                _config.ConfigurationJson = configurationJson;
                                _config.ConfigurationVersion = _config.ConfigurationVersion+1;

                                var result = _contextFactory.OmniaConfigurations.Update(_config);
                                _contextFactory.SaveChanges();

                                // Success full edit
                                formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                                formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyEdited, "Configuration");
                            }
                        }
                        else
                        {
                            formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                            formStatus.FormStatusMessage = String.Format(SiteConstants.NoRowsFound, "Configuration Id");
                        }
                    }
                    else
                    {
                        formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                        formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "Configuration Name, Configuration Id");
                    }
                }
                


            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = String.Format(SiteConstants.RowInsertFailed, "Role Name");
            }

            TempData.Put("FormStatus", formStatus);
            TempData.Put("Projects", _contextFactory.OmniaProjects);

            return View(_config);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteConfiguration(int configurationId)
        {
            FormStatus formStatus = new FormStatus();

            try
            {
                OmniaConfiguration _config = (configurationId != 0) ? _contextFactory.OmniaConfigurations
                    .Where(x => x.Id == configurationId).FirstOrDefault() : null;

                if (_config != null)
                {
                    formStatus = new FormStatus();

                    // Archieve the configuration before saving
                    ArchieveConfiguration(_config);

                    var result = _contextFactory.OmniaConfigurations.Remove(_config);
                    _contextFactory.SaveChanges();

                    formStatus.FormStatusCode = SiteConstants.FormCode_Success;
                    formStatus.FormStatusMessage = String.Format(SiteConstants.RowSuccessfullyDelete, "Configuration");
                }
                else
                {
                    formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                    formStatus.FormStatusMessage = String.Format(SiteConstants.RequiredField, "Configuration Id");
                }
            }
            catch (Exception ex)
            {
                formStatus = new FormStatus();
                formStatus.FormStatusCode = SiteConstants.FormCode_Fail;
                formStatus.FormStatusMessage = ex.ToString();
            }


            TempData.Put("FormStatus", formStatus);
            //return View("~/Views/ConfigurationManager/Index");
            return RedirectToAction("Index");
        }


        private void ArchieveConfiguration(OmniaConfiguration _config)
        {
            try
            {
                // Archieve the configuration before saving
                {
                    var archivedVersion = new OmniaArchivedConfiguration()
                    {
                        ConfigurationId = _config.Id,
                        ConfigurationVersion = _config.ConfigurationVersion,
                        ConfigurationJson = _config.ConfigurationJson,
                    };

                    // Add latest version in archieved table
                    _contextFactory.OmniaArchivedConfigurations.Add(archivedVersion);

                    // Claenup old archieves
                    var oldArchieves = _contextFactory.OmniaArchivedConfigurations
                        .Where(x => x.ConfigurationId == _config.Id).
                        OrderByDescending(x => x.ConfigurationVersion).Skip(SiteConstants.ArchievedVersionsCount);

                    foreach (var deletableArchieves in oldArchieves)
                    {
                        _contextFactory.OmniaArchivedConfigurations.Remove(deletableArchieves);
                    }

                    _contextFactory.SaveChanges();
                }
            }
            catch (Exception ex)
            {

            }
        }

    }
}
