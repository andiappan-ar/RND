﻿namespace OMNIA.MS.ID.Management.Models.ViewModels
{
    public class FormStatus
    {
        public string FormStatusCode { get; set; }
        public string FormStatusMessage { get; set; } 
    }
}
