﻿namespace OMNIA.MS.ID.Management.Models.ViewModels
{
    public class ConfigurationManagerModel
    {
        public int Id { get; set; }
        public string ConfigurationName { get; set; }
        public int ConfigurationVersion { get; set; }
        public string ConfigurationJson { get; set; }
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
    }
}
