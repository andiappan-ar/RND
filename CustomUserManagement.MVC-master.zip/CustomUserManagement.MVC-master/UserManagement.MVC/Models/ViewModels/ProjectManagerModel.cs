﻿namespace OMNIA.MS.ID.Management.Models.ViewModels
{
    public class ProjectManagerModel
    {
        public int Id { get; set; }
        public string ProjectName { get; set; }
        public string RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
