﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace OMNIA.MS.ID.Management.Models.EntityModels;

[Table("Omnia.Project")]
public partial class OmniaProject
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(100)]
    public string ProjectName { get; set; }

    [Required]
    [StringLength(450)]
    public string RoleId { get; set; }
}
