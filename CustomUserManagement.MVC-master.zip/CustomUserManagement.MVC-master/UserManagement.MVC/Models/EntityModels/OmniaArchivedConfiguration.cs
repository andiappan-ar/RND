﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace OMNIA.MS.ID.Management.Models.EntityModels;

[Table("Omnia.ArchivedConfiguration")]
public partial class OmniaArchivedConfiguration
{
    [Key]
    public int Id { get; set; }

    public int ConfigurationVersion { get; set; }

    [Required]
    public string ConfigurationJson { get; set; }

    public int ConfigurationId { get; set; }
}
